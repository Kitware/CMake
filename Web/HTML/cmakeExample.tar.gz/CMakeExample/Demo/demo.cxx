#include <iostream>
#include "hello.h"

extern Hello hello;

int main()
{
  hello.Print(std::cout);
  
  return 0;
}
