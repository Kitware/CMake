#include "hello.h"

void Hello::Print(std::ostream& os)
{
  os << "Hello, World!" << std::endl;
}
