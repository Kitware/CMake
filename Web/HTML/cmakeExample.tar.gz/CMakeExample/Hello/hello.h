#ifndef _hello_h
#define _hello_h

#include <ostream>

class Hello
{
public:
  void Print(std::ostream&);
};

#endif
